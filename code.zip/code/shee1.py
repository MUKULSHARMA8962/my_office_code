import openpyxl
import pandas as pd

def unprotect_sheet(sheet, password=None):
    if sheet.protection.sheet:
        sheet.protection.disable()

def protect_sheet(sheet, password=None):
    sheet.protection.enable()

def paste_data_to_sheet(sheet, data, start_cell='A1'):
    start_row = sheet[start_cell].row
    start_col = sheet[start_cell].column

    for i, row in data.iterrows():
        for j, value in enumerate(row):
            sheet.cell(row=start_row + i, column=start_col + j, value=value)

# Example data to be pasted into Excel
data = {
    'Column1': [1, 2, 3],
    'Column2': [4, 5, 6],
    'Column3': [7, 8, 9]
}
df = pd.DataFrame(data)

# Path to the file
file_path = 'base_file//PY2025PlansBenefitsTemplate.xlsm'

# Load workbook and select sheet
workbook = openpyxl.load_workbook(file_path)
sheet_name = 'Benefits Package 1'
sheet = workbook[sheet_name]

# Unprotect sheet
unprotect_sheet(sheet)

# Paste data into the specified sheet and cell
start_cell = 'A1'
paste_data_to_sheet(sheet, df, start_cell=start_cell)

# Protect sheet
protect_sheet(sheet)

# Save the workbook
workbook.save(file_path)

print("Data has been pasted into the specified sheet of the Excel file by value.")
