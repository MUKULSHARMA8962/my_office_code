import openpyxl
import pandas as pd

# Load the Excel file
excel_path = 'base_file//PY2025PlansBenefitsTemplate.xlsm'
wb = openpyxl.load_workbook(excel_path, keep_vba=True)

# Load the CSV file
csv_path = 'input_file//qhp_a2ch.csv'
csv_data = pd.read_csv(csv_path)

# Specify the source cell in the CSV
csv_row = 1  # 2nd row in CSV (index 1 because of 0-based indexing in pandas)
csv_column = 7  # 3rd column in CSV (index 2 because of 0-based indexing in pandas)

# Get the value from the CSV
value_to_update = csv_data.iloc[csv_row, csv_column]

# Specify the target cell in the Excel sheet
target_cell = 'E5'
sheet_name = 'Cost Share Variances 1'  # Change this to the correct sheet name

# Check if the sheet exists, otherwise create it
if sheet_name in wb.sheetnames:
    ws = wb[sheet_name]
else:
    ws = wb.create_sheet(title=sheet_name)

# Update the target cell with the value from the CSV
ws[target_cell] = value_to_update

# Save the updated Excel file
wb.save('Updated_PY2025PlansBenefitsTemplate.xlsm')
print("Cell updated successfully!")
