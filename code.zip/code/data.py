# import pandas as pd
# from openpyxl import load_workbook

# # Sample DataFrame (replace this with your actual DataFrame)
# data = {
#     'A': [10.123, 20.456, 30.789],
#     'B': [40.111, 50.222, 60.333],
#     'C': [70.444, 80.555, 90.666],
#     'D': [70.444, 80.555, 90.666],
#     'E': [70.444, 80.555, 90.666],
# }
# df = pd.DataFrame(data)

# # Load the existing Excel workbook
# file_path = 'base_file//PY2025PlansBenefitsTemplate.xlsm'
# workbook = load_workbook(file_path)
# sheet = workbook['Cost Share Variances 1']  # The sheet where you want to paste the data
# sheet.protection.disable() 
# # Define the starting cell where you want to paste the DataFrame values
# start_row = 5
# start_col = 5

# # Function to copy values without changing formatting
# def copy_values_without_changing_formatting(df, sheet, start_row, start_col):
#     for i, row in enumerate(df.itertuples(index=False, name=None), start=start_row):
#         for j, value in enumerate(row, start=start_col):
#             cell = sheet.cell(row=i, column=j)
#             cell.value = value

# # Copy DataFrame values to the Excel sheet
# copy_values_without_changing_formatting(df, sheet, start_row, start_col)

# # Save the workbook
# workbook.save('your_new_excel_file.xlsm')


import openpyxl

def copydata():
    # Load the workbooks
    wb_input = openpyxl.load_workbook(r"C://Users//al98888//OneDrive - Elevance Health//Documents//Test//output_PY2025PlansBenefitsTemplate.xlsm")
    wb_output = openpyxl.load_workbook(r"C://Users//al98888//OneDrive - Elevance Health//Documents//Test//PY2025PlansBenefitsTemplate.xlsm")

    # Select the worksheets
    ws_input = wb_input["Benefit PKG 9"]
    ws_output = wb_output["testing"]

    # Find the last row in the input sheet starting from row 58
    inLR = 58
    while ws_input.cell(row=inLR, column=1).value is not None:
        inLR += 1

    # Find the last row in the output sheet starting from row 58
    outLR = 58
    while ws_output.cell(row=outLR, column=1).value is not None:
        outLR += 1

    j = outLR

    # Copy data from input sheet to output sheet
    for i in range(8, inLR):
        for col in range(1, 31):  # Columns A to AD are 1 to 30
            ws_output.cell(row=j, column=col).value = ws_input.cell(row=i, column=col).value
        j += 1

    # Save the output workbook
    wb_output.save(r"C://Users//al98888//OneDrive - Elevance Health//Documents//Test//PY2025PlansBenefitsTemplate.xlsm")

# Call the function
copydata()
