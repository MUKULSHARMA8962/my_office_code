import pandas as pd
import openpyxl
from openpyxl.utils import get_column_letter
from openpyxl import load_workbook

# Load the workbook with VBA macros enabled
file_path = 'base_file//PY2025PlansBenefitsTemplate.xlsm'
workbook = load_workbook(file_path, keep_vba=True)

# Load the CSV files into DataFrames
mindsection_df = pd.read_csv("input_file//qhp_midsection.csv")
hp_a2ch_df = pd.read_csv("input_file//qhp_a2ch.csv")
qhp_costshare_df = pd.read_csv("input_file//qhp_costshare.csv")

# Step 2: List of columns to delete
columns_to_delete = ['Plan Modified date', 'Refresh Date', 'Plan Marketing Name_old*', 'URL for Summary of Benefits & Coverage', 'Plan Brochure']
hp_a2ch_df.drop(columns=columns_to_delete, inplace=True)

# Rename columns in qhp_costshare_df
column_mapping = {
    'hios_plan_id_with_variant': '0HIOS_Plan_ID_With_Variant',
    'Benefit1_INN_Copay': '2_Primary Care Visit to Treat an Injury or Illness_Benefit1_INN_Copay',
}
qhp_costshare_df = qhp_costshare_df.rename(columns=column_mapping)
qhp_costshare_df = qhp_costshare_df.drop(0)

# Merge DataFrames
merged_df = pd.merge(
    hp_a2ch_df,
    qhp_costshare_df,
    left_on='HIOS Plan ID* (Standard Component + Variant)',
    right_on='0HIOS_Plan_ID_With_Variant',
    how='outer'
)

sheet = workbook['Benefits Package 1']  # The sheet where you want to paste the data
sheet.protection.disable()
# Define the starting cell where you want to paste the DataFrame values
start_row = 9
start_col = 1

# Function to copy values without changing formatting
def copy_values_without_changing_formatting(df, sheet, start_row, start_col):
    for i, row in enumerate(df.itertuples(index=False, name=None), start=start_row):
        for j, value in enumerate(row, start=start_col):
            cell = sheet.cell(row=i, column=j)
            # If cell is part of a merged cell, find the start cell of the merged region
            if isinstance(cell, openpyxl.cell.MergedCell):
                for merged_range in sheet.merged_cells.ranges:
                    if cell.coordinate in merged_range:
                        cell = sheet.cell(row=merged_range.min_row, column=merged_range.min_col)
                        break
            cell.value = value

# Copy DataFrame values to the Excel sheet
copy_values_without_changing_formatting(mindsection_df, sheet, start_row, start_col)

# Save the workbook with the same file extension to keep VBA macros
workbook.save('your_new_excel_file.xlsm')



# # Drop unnecessary columns
# columns_to_drop = ['0HIOS_Plan_ID_With_Variant']
# merged_df = merged_df.drop(columns=columns_to_drop)
# merged_df['hios_id'] = merged_df['HIOS Plan ID* (Standard Component + Variant)'].str.split('-').str[0].str.strip()

# # Template sheet name for copying the structure
# template_sheet_name = 'Benefits Package 1'

# # Helper function to set cell values while maintaining formatting
# def set_cell_value(sheet, cell_reference, value):
#     font = Font(name='Arial', size=11)
#     for merged_range in sheet.merged_cells.ranges:
#         if cell_reference in merged_range:
#             min_row, min_col, _, _ = merged_range.bounds
#             top_left_cell = sheet.cell(row=min_row, column=min_col)
#             top_left_cell.value = value
#             top_left_cell.font = font
#             return
#     cell = sheet[cell_reference]
#     cell.value = value
#     cell.font = font

# # Function to copy DataFrame values to the Excel sheet without changing formatting
# def copy_values_without_changing_formatting(df, sheet, start_row, start_col):
#     font = Font(name='Arial', size=11)
#     for i, row in enumerate(df.itertuples(index=False, name=None), start=start_row):
#         for j, value in enumerate(row, start=start_col):
#             cell = sheet.cell(row=i, column=j)
#             cell.value = value
#             cell.font = font

# # Process Benefit Package sheets
# def process_benefit_package_sheet(value, sheet_name):
#     if sheet_name in workbook.sheetnames:
#         sheet = workbook[sheet_name]
#     else:
#         template_sheet = workbook[template_sheet_name]
#         sheet = workbook.copy_worksheet(template_sheet)
#         sheet.title = sheet_name

#     sheet.protection.disable()  # Disable sheet protection

#     BenefitPackage = value['Benefit Package']
#     BenefitInformation = value['Benefit Information']

#     if BenefitPackage.empty or BenefitInformation.empty:
#         return False

#     first_row_value = BenefitPackage.iloc[0]
#     hios_plan_id = first_row_value['HIOS Plan ID*(Standard Component)']
#     ke = hios_plan_id[:5]
#     state = hios_plan_id[5:7]

#     market_coverage = mindsection_df['Market Coverage*'].iloc[0] if 'Market Coverage*' in mindsection_df.columns else 'Individual'
#     dental_only_plan = mindsection_df['Dental Only Plan*'].iloc[0] if 'Dental Only Plan*' in mindsection_df.columns else 'No'

#     set_cell_value(sheet, 'B2', ke)
#     set_cell_value(sheet, 'B3', state)
#     set_cell_value(sheet, 'B4', market_coverage)
#     set_cell_value(sheet, 'B5', dental_only_plan)

#     left_join = pd.merge(
#         mindsection_df,
#         BenefitPackage.rename(columns={'HIOS Plan ID*(Standard Component)': 'HIOS Plan ID* (Standard Component)'}),
#         on='HIOS Plan ID* (Standard Component)',
#         how='left',
#         indicator=True
#     )

#     filtered_left_join = left_join[left_join['_merge'] == 'both'].drop(columns='_merge')
#     columns_to_drop = ['lastModificationDate', 'Refresh Date', 'Plan Marketing Name*_x', 'Level of Coverage*_x', 'Plan Type*_x']
#     filtered_left_join = filtered_left_join.drop(columns=columns_to_drop)
#     columns_to_rename = {'Plan Marketing Name*_y': 'Plan Marketing Name*', 'Level of Coverage*_y': 'Level of Coverage*', 'Plan Type*_y': 'Plan Type*'}
#     filtered_left_join = filtered_left_join.rename(columns=columns_to_rename)

#     required_columns = [
#         "HIOS Plan ID* (Standard Component)",
#         "Plan Marketing Name*", "HIOS Product ID*",
#         "Network ID*", "Service Area ID*", "Formulary ID*", "New/Existing Plan?*",
#         "Plan Type*", "Level of Coverage*", "Design Type*", "Unique Plan Design?*",
#         "QHP/Non QHP*", "Notice Required for Pregnancy*", "Plan Level Exclusions",
#         "Limited Cost Sharing Plan Variation - Est Advanced Payment",
#         "Does this plan offer Composite Rating?*", "Child-Only Offering*",
#         "Child Only Plan ID", "Tobacco Wellness Program Offered*",
#         "Disease Management Programs Offered", "EHB Percent of Total Premium*",
#         "EHB Apportionment for Pediatric Dental", "Guaranteed vs_ Estimated Rate",
#         "Plan Effective Date*", "Plan Expiration Date", "Out of Country Coverage*",
#         "Out of Country Coverage Description", "Out of Service Area Coverage*",
#         "Out of Service Area Coverage Description", "National Network*"
#     ]

#     existing_columns = [col for col in required_columns if col in filtered_left_join.columns]
#     filtered_left_join = filtered_left_join[existing_columns]

#     start_row = 8
#     copy_values_without_changing_formatting(filtered_left_join, sheet, start_row, 1)

#     BenefitInformation = BenefitInformation.drop(BenefitInformation.columns[0], axis=1)

#     benefit_start_row = 60
#     benefit_start_col = 3
#     copy_values_without_changing_formatting(BenefitInformation, sheet, benefit_start_row, benefit_start_col)

#     return True

# # Create and populate a Cost Share Variances sheet
# def create_and_populate_cost_share_variances_sheet(base_sheet_name, new_sheet_name, data):
#     global data_written

#     if new_sheet_name in workbook.sheetnames:
#         sheet = workbook[new_sheet_name]
#     else:
#         if base_sheet_name in workbook.sheetnames:
#             base_sheet = workbook[base_sheet_name]
#             sheet = workbook.copy_worksheet(base_sheet)
#             sheet.title = new_sheet_name
#         else:
#             raise ValueError(f"Base sheet '{base_sheet_name}' not found in the workbook.")

#     sheet.protection.disable()  # Disable sheet protection

#     start_row = 4
#     font = Font(name='Arial', size=11)

#     data = data[[
#         'HIOS Plan ID* (Standard Component + Variant)', 'Plan Marketing Name*', 
#         'Level of Coverage* (Metal Level)', 'CSR Variation Type*', 'Issuer Actuarial Value', 
#         'AV Calculator Output Number*', 'Medical & Drug Deductibles Integrated?*'
#     ]]

#     copy_values_without_changing_formatting(data, sheet, start_row, 1)

#     sheet.freeze_panes = 'F2'

#     max_row = sheet.max_row
#     for row in range(max_row, start_row - 1, -1):
#         if all(cell.value is None for cell in sheet[row]):
#             sheet.delete_rows(row)

#     data_written = True

#     return True

# for key, value in dfs.items():
#     if process_benefit_package_sheet(value, key):
#         data_written = True
#         hios_plan_ids = value['Benefit Package']['HIOS Plan ID*(Standard Component)'].unique()
#         filtered_cost_share_data = merged_df[merged_df['hios_id'].isin(hios_plan_ids)].copy()
#         filtered_cost_share_data = filtered_cost_share_data.drop([9, 8, 7, 6, 5, 4, 3, 2, 1, 0])
#         create_and_populate_cost_share_variances_sheet("data 2", f"Cost Share Variances {key.split()[-1]}", filtered_cost_share_data)

# if data_written:
#     for sheet_name in ['ram', 'data 1', 'data 2']:
#         if sheet_name in workbook.sheetnames:
#             del workbook[sheet_name]

#     new_file_path = 'output//output_PY2025PlansBenefitsTemplate.xlsm'
#     workbook.save(new_file_path)
#     print(f"Workbook saved as '{new_file_path}'")
# else:
#     print("No data was written.")
